package com.hp.rocket.entity;

import lombok.Data;

@Data
public class MessageBack {

    private String id;
    private String msg;
}
