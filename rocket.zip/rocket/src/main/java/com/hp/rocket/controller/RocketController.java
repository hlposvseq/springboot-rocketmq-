package com.hp.rocket.controller;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.hp.rocket.common.CodeMsg;
import com.hp.rocket.common.HPResponse;
import com.hp.rocket.service.RocketMqService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

@RequestMapping("rocket")
@RestController
public class RocketController {

    @Autowired
    RocketMqService rocketMqService;

    @GetMapping(value = "getResult/{msg}")
    public HPResponse<SendResult> getResult(@PathVariable("msg") String msg){
        if(StringUtils.isEmpty(msg)){
            return HPResponse.error(CodeMsg.SYSTEM_ERROR.fillArgs("参数不能为空"));
        }
        SendResult result = rocketMqService.openAccountMsg(msg);
        return HPResponse.success(result);
    }
}
