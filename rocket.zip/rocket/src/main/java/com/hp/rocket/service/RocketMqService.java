package com.hp.rocket.service;

import com.alibaba.rocketmq.client.consumer.PullResult;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.hp.rocket.entity.MessageBack;

import java.util.List;

public interface RocketMqService {

    SendResult openAccountMsg(String msgInfo);

}
