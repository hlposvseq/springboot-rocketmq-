package com.hp.rocket.common;

public class HPResponse<T> {


    private int code;
    private String msg;
    private T data;
    public static <T> HPResponse<T> success(T data){
        return new HPResponse<T>(data);
    }

    public static <T> HPResponse<T> success(){
        return new HPResponse<T>();
    }

    public static <T> HPResponse<T> error(CodeMsg codeMsg){
        return new  HPResponse<T>(codeMsg);
    }
    private HPResponse(T data) {
        this.code = 200;
        this.msg = "success";
        this.data = data;
    }

    private HPResponse() {
        this.code = 200;
        this.msg = "success";
    }

    private HPResponse(CodeMsg codeMsg) {
        if(codeMsg == null) {
            return;
        }
        this.code = codeMsg.getCode();
        this.msg = codeMsg.getMsg();
    }
    public int getCode() {
        return code;
    }
    public String getMsg() {
        return msg;
    }
    public T getData() {
        return data;
    }


}
