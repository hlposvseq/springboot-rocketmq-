package com.hp.rocket.common;

import lombok.Getter;

@Getter
public class CodeMsg {

    private int code;
    private String msg;

    public static CodeMsg SERVER_ERROR = new CodeMsg(50000, "服务端异常");
    public static CodeMsg SYSTEM_ERROR = new CodeMsg(40000, "%s");

    private CodeMsg(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public CodeMsg fillArgs(Object ... args){
        String message = String.format(this.msg,args);
        return new CodeMsg(this.code,message);
    }


}
